<img src="https://img.shields.io/badge/-building-green">
# 请修改BepInEx\config\AutoTranslatorConfig.ini
# [Baidu]
# BaiduAppId=
# BaiduAppSecret=
# DelaySeconds=1
## 百度翻译api免费使用，请自行申请https://fanyi-api.baidu.com/       选择 通用翻译api

![USE](https://user-images.githubusercontent.com/65057243/113544219-76b7b880-961a-11eb-8f15-58b779a4e94b.png)
# 文件放在游戏目录下，然后运行游戏即可 如出现字体缺少，请按ALT+F
